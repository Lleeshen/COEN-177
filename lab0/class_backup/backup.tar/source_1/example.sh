echo "$(date)" >> results.txt
sort q1.txt | uniq -u >> results.txt
echo "$(date)" >> results.txt
